<?php
/*
Plugin Name: Cotizador Nova Persianas
Plugin URI:
Description: Cotizador de persianas 
Version: 1.5
Author: Smarttree
Author URI:
Text Domain: cotizador-nova-persianas
*/
//Funcion para agregar el Meta Box con los campos necesarios
//en seccion del producto
add_action('add_meta_boxes', 'add_cotizador_nova');
if (!function_exists('add_cotizador_nova')) {
	function add_cotizador_nova($post)
	{
		global $woocommerce, $post, $wp_query;
		$terms_post = get_the_terms($post->cat_ID, 'product_cat');
		foreach ($terms_post as $term_cat) {
			$term_cat_id = $term_cat->term_id;
		}
		if ($term_cat_id !== 48 && $term_cat_id !== 49) {
			//Adding a custom Meta container to admin products pages
			add_meta_box(
				'custom_product_meta_box',
				__('Nova Persianas Cotizador', 'cmb'),
				'add_custom_content_meta_box',
				'product',
				'normal',
				'default'
			);
			//Custom metabox content in admin product pages
			if (!function_exists('add_custom_content_meta_box')) {
				function add_custom_content_meta_box($post)
				{
					//Adding a custom Meta container to admin products pages
					global $woocommerce, $post;
					echo '<style>.product_custom_field > p{display: grid}</style>';
					echo '<div class="product_custom_field">';
					//Valor Tela mas IVA
					woocommerce_wp_text_input(
						array(
							'id' => '_custom_valor_tela_number_field',
							'label' => __('Valor de la Tela + IVA', 'woocommerce'),
							'type' => 'number',
							'custom_attributes' => array(
								'step' => '0.1',
								'min' => '0'
							)
						)
					);
					//Rentabilidad
					woocommerce_wp_text_input(
						array(
							'id' => '_custom_rentabilidad_number_field',
							'label' => __('Rentabilidad en %', 'woocommerce'),
							'type' => 'number',
							'custom_attributes' => array(
								'step' => '0.1',
								'min' => '0'
							)
						)
					);
					//Instalación
					woocommerce_wp_text_input(
						array(
							'id' => '_custom_instalacion_number_field',
							'label' => __('Costo de Instalación', 'woocommerce'),
							'type' => 'number',
							'custom_attributes' => array(
								'step' => '0.1',
								'min' => '0'
							)
						)
					);
					echo '</div>';
				}
			}
		}
	}
}
//Guardar datos
add_action('woocommerce_process_product_meta', 'woocommerce_product_custom_fields_save');
function woocommerce_product_custom_fields_save($post_id)
{
	//Valor Tela mas IVA
	$woocommerce_custom_valor_tela_number_field = $_POST['_custom_valor_tela_number_field'];
	if (!empty($woocommerce_custom_valor_tela_number_field))
		update_post_meta($post_id, '_custom_valor_tela_number_field', esc_attr($woocommerce_custom_valor_tela_number_field));

	//Rentabilidad
	$woocommerce_custom_rentabilidad_number_field = $_POST['_custom_rentabilidad_number_field'];
	if (!empty($woocommerce_custom_rentabilidad_number_field))
		update_post_meta($post_id, '_custom_rentabilidad_number_field', esc_attr($woocommerce_custom_rentabilidad_number_field));

	//Instalación
	$woocommerce_custom_instalacion_number_field = $_POST['_custom_instalacion_number_field'];
	if (!empty($woocommerce_custom_instalacion_number_field))
		update_post_meta($post_id, '_custom_instalacion_number_field', esc_attr($woocommerce_custom_instalacion_number_field));
}
//Funcion que agrega el cotizador en el Front-end
add_action('woocommerce_after_add_to_cart_form', 'mish_before_add_to_cart_btn');
function mish_before_add_to_cart_btn()
{
	global $product;
	$valorTela = get_post_meta($product->get_id(), '_custom_valor_tela_number_field', true);
	$valorRentabilidad = get_post_meta($product->get_id(), '_custom_rentabilidad_number_field', true);
	$valorInstalacion = get_post_meta($product->get_id(), '_custom_instalacion_number_field', true);
	$product_id = $product->get_id();
	$product_name = $product->get_name();
	ob_start();
	if (!has_term('aluminio', 'product_cat', $product_id) && !has_term('madera', 'product_cat', $product_id)) {
?>
		<div class="content-nova">
			<span>¿tienes tus propias medidas? usa el cotizador virtual para conocer el precio</span>
			<button id="myBtn" class="btnCot">Cotizador Virtual</button>
			<div id="myModal" class="modal">
				<div class="modal-content">
					<h2 class="tituloCotizador">Cotizador Virtual<span class="close">X</span></h2>
					<form id="sendEmail" action="" method="post" enctype="multipart/form-data">
						<div class="formCoti">
							<label for="nombre">Nombre Completo*</label>
							<input id="nombre" type="text" name="nombre" required placeholder="Nombre Completo*">
							<span id="errorNombreM"></span>
							<label for="celular">Número de Contacto*</label>
							<input id="celular" type="number" name="celular" min="0" step="1" required placeholder="Número de Contacto*">
							<span id="errorCelularM"></span>
						</div>
						<div class="errors">
							<span id="errorNombre"></span>
							<span id="errorCelular"></span>
						</div>
						<div class="formCoti">
							<label for="correo">E-mail*</label>
							<input id="correo" type="email" name="correo" required placeholder="E-mail*">
							<span id="errorCorreoM"></span>
						</div>
						<div class="errors">
							<span id="errorEmail"></span>
						</div>
						<span>Introduce la medida (metros) en decimales, ejemplo: </span>
						<span>Alto: 2.56, Ancho: 1.05</span>
						<div class="DeskLabel">
							<label for="ancho" style="display: block;">Ancho (M)*</label>
							<label for="altura" style="display: block;padding-left: 1rem;">Alto (M)*</label>
						</div>
						<div class="formCoti" style="margin-top: 0;">
							<label for="ancho">Ancho (M)*</label>
							<input id="ancho" type="number" step="0.01" name="ancho" required placeholder="Ancho (M)*">
							<span id="errorAnchoM"></span>
							<label for="altura">Alto (M)*</label>
							<input id="altura" type="number" step="0.01" name="altura" required placeholder="Alto (M)*">
							<span id="errorAltoM"></span>
						</div>
						<div class="errors">
							<span id="errorAncho"></span>
							<span id="errorAltura"></span>
						</div>
						<input type="hidden" id="producto" name="producto" value="<?php echo $product_name ?>">
						<input type="hidden" id="cotizado" name="cotizado" value="">
						<input type="hidden" name="action" value="send_form">
						<input id="btnCotizar" class="btnCot" onclick="cotizar()" type="submit" value="Cotizar">
					</form>
					<div id="cotizacion" class="formCoti" style="display: none; text-align: left; flex-wrap: wrap;"></div>
				</div>
			</div>
		</div>
	<?php
	}
	?>
	<style>
		.content-nova {
			margin: 1rem auto;
			text-align: center;
		}

		.modal {
			display: none;
			position: fixed;
			z-index: 99999999;
			padding-top: 100px;
			left: 0;
			top: 0;
			width: 100%;
			height: 100%;
			overflow: auto;
			background-color: rgb(0, 0, 0);
			background-color: rgba(0, 0, 0, 0.4);
		}

		.close {
			cursor: pointer;
		}

		h2.tituloCotizador {
			margin: auto 3rem;
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		/* Modal Content */
		.formCoti {
			display: flex;
			margin: 2rem;
			align-items: center;
			justify-content: space-between;
		}

		.formCoti label {
			display: none;
		}

		.formCoti input {
			margin: 0 1rem;
		}

		.modal-content {
			background-color: #fefefe;
			margin: auto;
			padding: 20px;
			width: 65%;
			border-radius: 8px;
		}

		.modal-content>form {
			margin: 1rem auto;
		}

		.formCoti h5 {
			margin: 0 1rem;
		}

		.errors {
			display: none;
			align-items: center;
			justify-content: space-around;
			margin-top: -1.5rem;
		}

		.nota {
			margin: 1rem;
		}

		.DeskLabel {
			margin: 2rem;
			margin-bottom: 0;
			display: grid;
			grid-template-columns: 1fr 50%;
			margin-right: 3rem;
			margin-left: 3rem;
			justify-content: start;
			align-items: center;
			justify-items: start;
		}

		@media only screen and (max-width: 767.98px) {
			h2.tituloCotizador {
				margin: auto;
				justify-content: center;
			}

			h2.tituloCotizador span {
				display: none;
			}

			.content-nova .btnCot {
				display: grid;
			}

			.modal-content {
				width: 90%;
			}

			.modal-content>form {
				text-align: left;
			}

			.formCoti {
				margin: 0.5rem;
				display: inherit;
			}

			.formCoti input {
				width: 100% !important;
				margin: auto;
			}

			.formCoti input::placeholder {
				color: #0000;
			}

			.formCoti label {
				display: block;
				margin: 0.5rem 0;
			}

			.modal-content form span {
				margin: 0 0.5rem;
			}

			.modal-content form .btnCot {
				margin: 1rem 0.5rem;
			}

			.DeskLabel {
				display: none !important;
			}
		}
	</style>
	<script>
		// Get the modal
		var modal = document.getElementById("myModal");
		// Get the button that opens the modal
		var btn = document.getElementById("myBtn");
		// Get the <span> element that closes the modal
		var span = document.getElementsByClassName("close")[0];
		// When the user clicks the button, open the modal 
		btn.onclick = function() {
			modal.style.display = "block";
		}
		// When the user clicks on <span> (x), close the modal
		span.onclick = function() {
			modal.style.display = "none";
		}

		// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
			if (event.target == modal) {
				modal.style.display = "none";
			}
		}
	</script>
	<script type="text/javascript">
		function validar_email(email) {
			var regex = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			return regex.test(email) ? true : false;
		}

		function cotizar() {
			var btnCotizar = document.getElementById('cotizacion');
			var alto = document.getElementById('altura').value;
			var ancho = document.getElementById('ancho').value;
			var nombre = document.getElementById('nombre').value;
			var celular = document.getElementById('celular').value;
			var correo = document.getElementById('correo').value;
			var tela = <?php echo $valorTela ?>;
			var porsengeRentabilidad = <?php echo $valorRentabilidad ?>;
			var rentabilidad = porsengeRentabilidad + 100;
			var instalacion = <?php echo $valorInstalacion ?>;
			var resultado = (((alto * ancho * tela) * rentabilidad) / 100) + instalacion;
			const formateado = resultado.toLocaleString("en", {
				style: "currency",
				currency: "COP"
			});
			const boxes = Array.from(
				document.getElementsByClassName('errors')
			);
			var x = window.matchMedia("(max-width: 700px)")
			if (!x.matches) {
				boxes.forEach(box => {
					box.style.display = 'flex';
				});
			} else {
				boxes.forEach(box => {
					box.style.display = 'none';
				});
			}
			if (alto > 0 && ancho > 0) {
				btnCotizar.style.display = 'flex';
				btnCotizar.style.justifyContent = 'flex-start';
				document.getElementById("cotizado").value = Math.round(resultado);
				document.getElementById("cotizacion").innerHTML = `<h5>Valor Cotizado: </h5><span>${formateado}</span>
				<span class="nota">Este valor es una estimación, el valor puede cambiar dependiendo de las verdaderas medidas del lugar de instalación. 
				El valor cotizado no incluye el valor del envío de la persiana, que dependerá de la locación de la instalación.</span>
				<span class="nota">Esta cotización ha sido enviada a uno de nuestros asesores y se contactará contigo en el menor tiempo posible para 
				brindarte más información acerca de este producto.</span>`;
			}
			if (alto <= 0) {
				btnCotizar.style.display = 'none';
				if (!x.matches) {
					document.getElementById('errorAltura').innerHTML = 'Este campo es requerido';
					document.getElementById('errorAltura').style.cssText = "color:red;margin-left:1.5rem;"
				} else {
					document.getElementById('errorAltoM').innerHTML = 'Este campo es requerido';
					document.getElementById('errorAltoM').style.cssText = "margin:0;color:red;";
				}
			} else {
				document.getElementById('errorAltura').innerHTML = '';
				document.getElementById('errorAltoM').innerHTML = '';
			}
			if (ancho <= 0) {
				btnCotizar.style.display = 'none';
				if (!x.matches) {
					document.getElementById('errorAncho').innerHTML = 'Este campo es requerido';
					document.getElementById('errorAncho').style.cssText = "color:red;"
				} else {
					document.getElementById('errorAnchoM').innerHTML = 'Este campo es requerido';
					document.getElementById('errorAnchoM').style.cssText = "margin:0;color:red;";
				}
			} else {
				document.getElementById('errorAncho').innerHTML = '';
				document.getElementById('errorAnchoM').innerHTML = '';
			}
			if (nombre.length <= 0) {
				btnCotizar.style.display = 'none';
				if (!x.matches) {
					document.getElementById('errorNombre').innerHTML = 'Este campo es requerido';
					document.getElementById('errorNombre').style.cssText = "color:red;"
				} else {
					document.getElementById('errorNombreM').innerHTML = 'Este campo es requerido';
					document.getElementById('errorNombreM').style.cssText = "margin:0;color:red;"
				}
			} else {
				document.getElementById('errorNombre').innerHTML = '';
				document.getElementById('errorNombreM').innerHTML = '';
			}
			if (celular == '' || celular.length <= 6) {
				btnCotizar.style.display = 'none';
				if (!x.matches) {
					document.getElementById('errorCelular').innerHTML = 'Este campo es requerido con minimo 7 digitos';
					document.getElementById('errorCelular').style.cssText = "color:red;"
				} else {
					document.getElementById('errorCelularM').innerHTML = 'Este campo es requerido con minimo 7 digitos';
					document.getElementById('errorCelularM').style.cssText = "margin:0;color:red;";
				}

			} else {
				document.getElementById('errorCelular').innerHTML = '';
				document.getElementById('errorCelularM').innerHTML = '';
			}
			if (celular < 0) {
				if (!x.matches) {
					document.getElementById('errorCelular').innerHTML = 'Introduzca un número valido';
					document.getElementById('errorCelular').style.cssText = "color:red;";
				} else {
					document.getElementById('errorCelularM').innerHTML = 'Introduzca un número valido';
					document.getElementById('errorCelularM').style.cssText = "margin:0;color:red;";
				}
			}
			if (correo.length <= 0) {
				btnCotizar.style.display = 'none';
				if (!x.matches) {
					document.getElementById('errorEmail').innerHTML = 'Este campo es requerido';
					document.getElementById('errorEmail').style.cssText = "color:red;"
				} else {
					document.getElementById('errorCorreoM').innerHTML = 'Este campo es requerido';
					document.getElementById('errorCorreoM').style.cssText = "margin:0;color:red;";
				}
			} else {
				document.getElementById('errorEmail').innerHTML = '';
				document.getElementById('errorCorreoM').innerHTML = '';
				if (!validar_email(correo)) {
					btnCotizar.style.display = 'none';
					if (!x.matches) {
						document.getElementById('errorEmail').innerHTML = 'Introduzca un correo valido';
						document.getElementById('errorEmail').style.cssText = "color:red;"
					} else {
						document.getElementById('errorCorreoM').innerHTML = 'Introduzca un correo valido';
						document.getElementById('errorCorreoM').style.cssText = "margin:0;color:red;";
					}
				} else {
					document.getElementById('errorEmail').innerHTML = '';
					document.getElementById('errorCorreoM').innerHTML = '';
				}
			}
		}
	</script>
	<script type="text/javascript">
		jQuery(document).ready(function($) {
			var frm = $('#sendEmail');
			frm.submit(function(e) {
				var formData = {
					nombre: jQuery('#nombre').val(),
					celular: jQuery('#celular').val(),
					correo: jQuery('#correo').val(),
					producto: jQuery('#producto').val(),
					altura: jQuery('#altura').val(),
					ancho: jQuery('#ancho').val(),
					cotizado: jQuery('#cotizado').val(),
					action: 'send_mail'
				};
				$.ajax({
					type: 'POST',
					url: "<?php echo admin_url('admin-ajax.php'); ?>",
					data: formData,
					dataType: 'json',
					encode: true
				});
				e.preventDefault();
			});

		});
	</script>
<?php
}
function send_mail()
{
	$nombre = sanitize_text_field($_POST['nombre']);
	$celular = sanitize_text_field($_POST['celular']);
	$correo = sanitize_email($_POST['correo']);
	$producto = sanitize_text_field($_POST['producto']);
	$altura = sanitize_text_field($_POST['altura']);
	$ancho = sanitize_text_field($_POST['ancho']);
	$cotizado = sanitize_text_field($_POST['cotizado']);
	setlocale(LC_MONETARY, 'es_CO');
	$format = money_format('%.2n', $cotizado);

	$to = 'info@novapersianas.com';
	$subject = 'Nueva Cotización';
	$body .= "Nombre Completo: " . $nombre . "<br>";
	$body .= "Número de Contacto: " . $celular . "<br>";
	$body .= "Correo Electronico: " . $correo . "<br>";
	$body .= "Producto cotizado: " . $producto . "<br>";
	$body .= "Alto: " . $altura . "<br>";
	$body .= "Ancho: " . $ancho . "<br>";
	$body .= "Valor cotizado: " . $format . "<br>";
	$headers = array('Content-Type: text/html; charset=UTF-8');

	wp_mail($to, $subject, $body, $headers);
	echo 'mail send';
	die;
}
add_action("wp_ajax_send_mail", "send_mail");
add_action("wp_ajax_nopriv_send_mail", "send_mail");
